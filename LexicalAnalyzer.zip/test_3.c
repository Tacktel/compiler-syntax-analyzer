int a = 345;
char c = "hello";