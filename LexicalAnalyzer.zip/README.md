# compiler-lexical-analyzer

### How to launch

```
$ python3 lexical-analizer.py <input_file_name>
```