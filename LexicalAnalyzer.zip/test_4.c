while (1) {
    if (1 == 3) {
    }
    else {
        return 42;
    }
}