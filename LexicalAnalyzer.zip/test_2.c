int main(char a, char b) {
    int     i = 1;
    char d;

    if (1 == 1) {
        d = "";
    }
}